/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author LABORATORIO
 */
public class Calculadora_19_CarlosJuarez {

    public static void main(String[] args) {
        calculadora v1= new calculadora();
        v1.setVisible(true);
    }
}
